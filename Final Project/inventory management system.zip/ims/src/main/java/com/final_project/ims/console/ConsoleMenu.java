package com.final_project.ims.console;

import com.final_project.ims.model.*;
import com.final_project.ims.service.*;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Scanner;

@Component
public class ConsoleMenu implements CommandLineRunner {

    private final ProductService productService;
    private final CategoryService categoryService;
    private final SupplierService supplierService;
    private final ProductSupplierService productSupplierService;

    public ConsoleMenu(ProductService productService, CategoryService categoryService, SupplierService supplierService, ProductSupplierService productSupplierService) {
        this.productService = productService;
        this.categoryService = categoryService;
        this.supplierService = supplierService;
        this.productSupplierService = productSupplierService;
    }

    @Override
    public void run(String... args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\nINVENTORY MANAGEMENT SYSTEM");
            System.out.println("1. Product Management");
            System.out.println("2. Category Management");
            System.out.println("3. Supplier Management");
            System.out.println("4. Reports");
            System.out.println("5. Exit");

            int ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {
                case 1 -> productMenu(sc);
                case 2 -> categoryMenu(sc);
                case 3 -> supplierMenu(sc);
                case 4 -> reportMenu(sc);
                case 5 -> System.exit(0);
                default -> System.out.println("Invalid Choice");
            }
        }
    }

    private void productMenu(Scanner sc) {

        while (true) {
            System.out.println("\nPRODUCT MANAGEMENT");
            System.out.println("1. Add Product");
            System.out.println("2. View Products");
            System.out.println("3. Search Product");
            System.out.println("4. Update Product");
            System.out.println("5. Delete Product");
            System.out.println("6. Back");

            int ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {
                //Add
                case 1 -> {
                    Product p = new Product();

                    System.out.print("Product ID: ");
                    p.setId(sc.nextLine());

                    if(productService.getProductById(p.getId()) != null) {
                        System.out.println("Product ID already exists");
                        break;
                    }

                    System.out.print("Name: ");
                    p.setName(sc.nextLine());

                    System.out.print("Price: ");
                    p.setPrice(sc.nextDouble());

                    if(p.getPrice() <=0) {
                        System.out.println("Price must be greater than 0");
                        break;
                    }

                    System.out.print("Quantity: ");
                    p.setQuantity(sc.nextInt());
                    sc.nextLine();

                    if(p.getQuantity() <0) {
                        System.out.println("Quantity cannot be negative");
                        break;
                    }

                    System.out.print("Category ID: ");
                    String categoryId = sc.nextLine();

                    Category category = categoryService.getCategoryById(categoryId);

                    if(category == null) {
                        System.out.println("Category does not exist");
                        break;
                    }

                    p.setCategoryId(categoryId);

                    try {
                        productService.addProduct(p);
                        System.out.println("Product Added");
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                }
                //view
                case 2 -> {
                    List<Product> products = productService.getAllProducts();

                    if (products.isEmpty()) System.out.println("No Products Found");
                    else {
                        products.forEach(System.out::println);
                        System.out.println("Total Products: " + products.size());
                    }
                }
                //search
                case 3 -> {
                    System.out.print("Enter Product ID: ");
                    String id = sc.nextLine();
                    System.out.println(productService.getProductById(id));
                }
                //update
                case 4 -> {
                    System.out.print("Enter Product ID: ");
                    String id = sc.nextLine();

                    Product product = productService.getProductById(id);
                    if(product == null) {
                        System.out.println("Product Not Found");
                        break;
                    }

                    System.out.print("New Name: ");
                    product.setName(sc.nextLine());

                    System.out.print("New Price: ");
                    product.setPrice(Double.parseDouble(sc.nextLine()));

                    System.out.print("New Quantity: ");
                    product.setQuantity(Integer.parseInt(sc.nextLine()));

                    System.out.print("New Category ID: ");
                    product.setCategoryId(sc.nextLine());

                    try {
                        productService.updateProduct(id, product);
                        System.out.println("Product Updated");
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                }
                //delete
                case 5 -> {
                    System.out.print("Enter Product ID: ");
                    String id = sc.nextLine();

                    productService.deleteProduct(id);
                    System.out.println("Deleted");
                }

                case 6 -> {
                    return;
                }

                default -> System.out.println("Invalid Choice");
            }
        }
    }

    private void categoryMenu(Scanner sc) {

        while (true) {
            System.out.println("\nCATEGORY MANAGEMENT");
            System.out.println("1. Add Category");
            System.out.println("2. View Categories");
            System.out.println("3. Search Category");
            System.out.println("4. Update Category");
            System.out.println("5. Delete Category");
            System.out.println("6. Back");

            int ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {
                //add
                case 1 -> {
                    Category cat = new Category();

                    System.out.print("Category ID: ");
                    cat.setId(sc.nextLine());

                    if(categoryService.getCategoryById(cat.getId()) != null) {
                        System.out.println("Category ID already exists");
                        break;
                    }

                    System.out.print("Category Name: ");
                    cat.setCategoryName(sc.nextLine());

                    categoryService.addCategory(cat);
                    System.out.println("Category Added");
                }
                //view
                case 2 -> {
                    List<Category> categories = categoryService.getAllCategories();

                    if (categories.isEmpty()) System.out.println("No Categories Found");
                    else {
                        categories.forEach(System.out::println);
                        System.out.println("Total Categories: " + categories.size());
                    }
                }
                //search
                case 3 -> {
                    System.out.print("Enter Category ID: ");
                    String id = sc.nextLine();
                    Category category = categoryService.getCategoryById(id);

                    if (category == null) System.out.println("Category Not Found");
                    else System.out.println(category);
                }
                //update
                case 4 -> {
                    System.out.print("Enter Category ID: ");
                    String id = sc.nextLine();

                    Category category = categoryService.getCategoryById(id);

                    if (category == null) {
                        System.out.println("Category Not Found");
                        break;
                    }
                    System.out.print("New Category Name: ");
                    category.setCategoryName(sc.nextLine());

                    categoryService.updateCategory(id, category);
                    System.out.println("Category Updated");
                }
                //delete
                case 5 -> {
                    System.out.print("Enter Category ID: ");
                    String id = sc.nextLine();

                    categoryService.deleteCategory(id);
                    System.out.println("Category Deleted");
                }

                case 6 -> {
                    return;
                }

                default -> System.out.println("Invalid Choice");
            }
        }
    }

    private void supplierMenu(Scanner sc) {

        while (true) {
            System.out.println("\nSUPPLIER MANAGEMENT");
            System.out.println("1. Add Supplier");
            System.out.println("2. View Suppliers");
            System.out.println("3. Search Supplier");
            System.out.println("4. Update Supplier");
            System.out.println("5. Delete Supplier");
            System.out.println("6. Back");

            int ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {
                //add
                case 1 -> {

                    Supplier supplier = new Supplier();
                    System.out.print("Supplier ID: ");
                    supplier.setId(sc.nextLine());

                    if(supplierService.getSupplierById(supplier.getId()) != null) {
                        System.out.println("Supplier ID already exists");
                        break;
                    }

                    System.out.print("Supplier Name: ");
                    supplier.setSupplierName(sc.nextLine());

                    System.out.print("Contact: ");
                    supplier.setContact(sc.nextLine());

                    supplierService.addSupplier(supplier);

                    System.out.print("Product ID Supplied (Give space separated inputs in case of many1): ");
                    String productId = sc.nextLine();

                    String [] prodids = productId.split(" ");
                    for (String prodid : prodids) {

                        Product product = productService.getProductById(prodid);

                        if (product == null) {
                            System.out.println("Supplier Added");
                            System.out.println("Product ID not found. Mapping not created.");

                        } else {

                            ProductSupplier mapping = new ProductSupplier();

                            mapping.setProductId(prodid);
                            mapping.setSupplierId(supplier.getId());

                            productSupplierService.addMapping(mapping);

                            System.out.println("Supplier Added and Product Mapping Created");
                        }
                    }
                }
                //view
                case 2 -> {
                    List<Supplier> suppliers = supplierService.getAllSuppliers();

                    if (suppliers.isEmpty()) System.out.println("No Suppliers Found");
                    else {
                        suppliers.forEach(System.out::println);
                        System.out.println("Total Suppliers: " + suppliers.size());
                    }
                }
                //search
                case 3 -> {
                    System.out.print("Enter Supplier ID: ");
                    String id = sc.nextLine();

                    Supplier supplier = supplierService.getSupplierById(id);

                    if (supplier == null) System.out.println("Supplier Not Found");
                    else System.out.println(supplier);
                }
                //update
                case 4 -> {
                    System.out.print("Enter Supplier ID: ");
                    String id = sc.nextLine();

                    Supplier supplier = supplierService.getSupplierById(id);

                    if (supplier == null) {
                        System.out.println("Supplier Not Found");
                        break;
                    }

                    System.out.print("New Supplier Name: ");
                    supplier.setSupplierName(sc.nextLine());

                    System.out.print("New Contact: ");
                    supplier.setContact(sc.nextLine());

                    supplierService.updateSupplier(id, supplier);
                    System.out.println("Supplier Updated");
                }
                //delete
                case 5 -> {
                    System.out.print("Enter Supplier ID: ");
                    String id = sc.nextLine();

                    supplierService.deleteSupplier(id);

                    System.out.println("Supplier Deleted");
                }

                case 6 -> {
                    return;
                }

                default -> System.out.println("Invalid Choice");
            }
        }
    }

    private void reportMenu(Scanner sc) {
        while (true) {
            System.out.println("\nREPORTS");
            System.out.println("1. Products By Category");
            System.out.println("2. Low Stock Products");
            System.out.println("3. Back");

            int ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {
                case 1 -> {
                    System.out.print("Enter Category ID: ");
                    String categoryId = sc.nextLine();

                    List<Product> products = productService.getProductsByCategory(categoryId);

                    if (products.isEmpty()) System.out.println("No Products Found");
                    else products.forEach(System.out::println);
                }

                case 2 -> {
                    List<Product> products = productService.getLowStockProducts();

                    if (products.isEmpty()) System.out.println("No Low Stock Products");
                    else products.forEach(System.out::println);
                }

                case 3 -> {
                    return;
                }

                default -> System.out.println("Invalid Choice");
            }
        }
    }
}