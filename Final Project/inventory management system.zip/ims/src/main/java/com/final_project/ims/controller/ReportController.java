package com.final_project.ims.controller;

import com.final_project.ims.model.Product;
import com.final_project.ims.model.ProductSupplier;
import com.final_project.ims.model.Supplier;
import com.final_project.ims.repository.ProductRepository;
import com.final_project.ims.repository.SupplierRepository;
import com.final_project.ims.service.ProductService;
import com.final_project.ims.service.ProductSupplierService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/reports")
public class ReportController {

    @Autowired
    private ProductService productService;

    @Autowired
    private ProductSupplierService mappingService;

    @Autowired
    private SupplierRepository supplierRepository;

    @Autowired
    private ProductRepository productRepository;

    @GetMapping("/products-by-category/{categoryId}")
    public List<Product> getProductsByCategory(@PathVariable String categoryId) {
        return productService.getProductsByCategory(categoryId);
    }

    @GetMapping("/low-stock-products")
    public List<Product> getLowStockProducts() {
        return productService.getLowStockProducts();
    }

    @GetMapping("/suppliers-by-product/{productId}")
    public List<Supplier> getSuppliersByProduct(@PathVariable String productId) {

        List<ProductSupplier> mappings = mappingService.getMappingsByProduct(productId);
        List<Supplier> suppliers = new ArrayList<>();

        for (ProductSupplier mapping : mappings) supplierRepository.findById(mapping.getSupplierId()).ifPresent(suppliers::add);
        return suppliers;
    }

    @GetMapping("/products-by-supplier/{supplierId}")
    public List<Product> getProductsBySupplier(@PathVariable String supplierId) {

        List<ProductSupplier> mappings = mappingService.getMappingsBySupplier(supplierId);
        List<Product> products = new ArrayList<>();

        for (ProductSupplier mapping : mappings) productRepository.findById(mapping.getProductId()).ifPresent(products::add);
        return products;
    }
}