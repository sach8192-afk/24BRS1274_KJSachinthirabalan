package com.final_project.ims.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "product_suppliers")
public class ProductSupplier {

    @Id
    private String id;

    private String productId;
    private String supplierId;

    public ProductSupplier() {}

    public ProductSupplier(String id, String productId, String supplierId) {
        this.id = id;
        this.productId = productId;
        this.supplierId = supplierId;
    }

    @Override
    public String toString() {
        return "ProductSupplier{" +
                "id='" + id + '\'' +
                ", productId='" + productId + '\'' +
                ", supplierId='" + supplierId + '\'' +
                '}';
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getProductId() { return productId; }
    public void setProductId(String productId) {this.productId = productId;}

    public String getSupplierId() { return supplierId; }
    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }
}