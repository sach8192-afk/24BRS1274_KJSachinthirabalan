package com.final_project.ims.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "suppliers")
public class Supplier {

    @Id
    private String id;
    private String supplierName;
    private String contact;

    public Supplier() {}

    public Supplier(String id, String supplierName, String contact) {
        this.id = id;
        this.supplierName = supplierName;
        this.contact = contact;
    }

    @Override
    public String toString() {
        return "Supplier{" +
                "id='" + id + '\'' +
                ", supplierName='" + supplierName + '\'' +
                ", contact='" + contact + '\'' +
                '}';
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getSupplierName() { return supplierName; }
    public void setSupplierName(String supplierName) {this.supplierName = supplierName;}

    public String getContact() { return contact; }
    public void setContact(String contact) {
        this.contact = contact;
    }
}