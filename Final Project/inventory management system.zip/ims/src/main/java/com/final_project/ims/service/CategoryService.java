package com.final_project.ims.service;

import com.final_project.ims.model.Category;
import com.final_project.ims.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryService {

    @Autowired
    private CategoryRepository repository;

    public List<Category> getAllCategories() {
        return repository.findAll();
    }

    public Category getCategoryById(String id) {
        return repository.findById(id).orElse(null);
    }

    public Category addCategory(Category category) {
        if (repository.existsById(category.getId())) {
            throw new IllegalArgumentException("Category ID already exists");
        }
        return repository.save(category);
    }

    public Category updateCategory(String id, Category category) {
        if (!repository.existsById(id)) {
            throw new IllegalArgumentException("Category not found");
        }
        category.setId(id);
        return repository.save(category);
    }

    public void deleteCategory(String id) {
        repository.deleteById(id);
    }
}