package com.final_project.ims.service;

import com.final_project.ims.model.Product;
import com.final_project.ims.repository.CategoryRepository;
import com.final_project.ims.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    @Autowired
    private ProductRepository repository;

    @Autowired
    private CategoryRepository categoryRepository;

    public List<Product> getAllProducts() {
        return repository.findAll();
    }

    public Product getProductById(String id) {
        return repository.findById(id).orElse(null);
    }

    public Product addProduct(Product product) {
        if (repository.existsById(product.getId())) {
            throw new IllegalArgumentException("Product ID already exists");
        }
        validateProduct(product);
        return repository.save(product);
    }

    public Product updateProduct(String id, Product product) {
        if (!repository.existsById(id)) {
            throw new IllegalArgumentException("Product not found");
        }
        product.setId(id);
        validateProduct(product);
        return repository.save(product);
    }

    private void validateProduct(Product product) {
        if (product.getPrice() <= 0) {
            throw new IllegalArgumentException("Price must be greater than 0");
        }
        if (product.getQuantity() < 0) {
            throw new IllegalArgumentException("Quantity cannot be negative");
        }
        if (!categoryRepository.existsById(product.getCategoryId())) {
            throw new IllegalArgumentException("Category does not exist");
        }
    }

    public void deleteProduct(String id) {
        repository.deleteById(id);
    }

    public List<Product> getProductsByCategory(String categoryId) {
        return repository.findByCategoryId(categoryId);
    }

    public List<Product> getLowStockProducts() {
        return repository.findByQuantityLessThan(10);
    }
}