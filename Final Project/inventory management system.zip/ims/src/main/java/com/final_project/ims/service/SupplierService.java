package com.final_project.ims.service;

import com.final_project.ims.model.Supplier;
import com.final_project.ims.repository.SupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SupplierService {

    @Autowired
    private SupplierRepository repository;

    public List<Supplier> getAllSuppliers() {
        return repository.findAll();
    }

    public Supplier getSupplierById(String id) {
        return repository.findById(id).orElse(null);
    }

    public Supplier addSupplier(Supplier supplier) {
        if (repository.existsById(supplier.getId())) {
            throw new IllegalArgumentException("Supplier ID already exists");
        }
        return repository.save(supplier);
    }

    public Supplier updateSupplier(String id, Supplier supplier) {
        if (!repository.existsById(id)) {
            throw new IllegalArgumentException("Supplier not found");
        }
        supplier.setId(id);
        return repository.save(supplier);
    }

    public void deleteSupplier(String id) {
        repository.deleteById(id);
    }
}