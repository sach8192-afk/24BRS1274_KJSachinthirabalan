package com.final_project.ims.service;

import com.final_project.ims.model.ProductSupplier;
import com.final_project.ims.repository.ProductSupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductSupplierService {

    @Autowired
    private ProductSupplierRepository repository;

    public ProductSupplier addMapping(ProductSupplier mapping) {
        List<ProductSupplier> existing = repository.findByProductId(mapping.getProductId());

        for (ProductSupplier m : existing) {
            if (m.getSupplierId().equals(mapping.getSupplierId())) {
                throw new IllegalArgumentException("This supplier is already mapped to this product");
            }
        }

        return repository.save(mapping);
    }

    public List<ProductSupplier> getAllMappings() {
        return repository.findAll();
    }

    public void deleteMapping(String id) {
        repository.deleteById(id);
    }

    public List<ProductSupplier> getMappingsByProduct(String productId) {
        return repository.findByProductId(productId);
    }

    public List<ProductSupplier> getMappingsBySupplier(String supplierId) {
        return repository.findBySupplierId(supplierId);
    }
}