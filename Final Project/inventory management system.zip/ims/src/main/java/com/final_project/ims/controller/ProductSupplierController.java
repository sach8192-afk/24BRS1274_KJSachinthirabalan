package com.final_project.ims.controller;

import com.final_project.ims.model.ProductSupplier;
import com.final_project.ims.service.ProductSupplierService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/product-suppliers")
public class ProductSupplierController {

    @Autowired
    private ProductSupplierService service;

    @PostMapping
    public ProductSupplier addMapping(@RequestBody ProductSupplier mapping) {
        return service.addMapping(mapping);
    }

    @GetMapping
    public List<ProductSupplier> getAllMappings() {
        return service.getAllMappings();
    }

    @DeleteMapping("/{id}")
    public String deleteMapping(@PathVariable String id) {
        service.deleteMapping(id);
        return "Mapping Deleted";
    }
}