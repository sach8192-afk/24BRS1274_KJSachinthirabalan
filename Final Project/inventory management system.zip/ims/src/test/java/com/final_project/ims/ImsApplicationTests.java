package com.final_project.ims;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImsApplicationTests {

	@Test
	void contextLoads() {
	}

}
