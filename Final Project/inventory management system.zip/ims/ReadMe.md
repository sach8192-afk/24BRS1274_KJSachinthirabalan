# Inventory Management System

Sir I made this in IntelliJ as I have been using it since school for Java. So I used the generate function to generate getters, setters, contructors, interfaces. I hope it won't affect my marking.


### To run this project, Run:

```text
ImsApplication.java
```
## Collections

The application uses the following MongoDB collections:

* products
* categories
* suppliers
* product_suppliers

---

## Modules

### 1. Product Management

* Add Product
* View Product
* Update Product
* Delete Product

### 2. Category Management

* Add Category
* View Category
* Update Category
* Delete Category

### 3. Supplier Management

* Add Supplier
* View Supplier
* Update Supplier
* Delete Supplier

### 5. Reports

* Products By Category
* Low Stock Products

---

## APIs

### Product Management APIs

| Method | URL                                     |
| ------ | --------------------------------------- |
| GET    | http://localhost:8080/api/products      |
| GET    | http://localhost:8080/api/products/{id} |
| POST   | http://localhost:8080/api/products      |
| PUT    | http://localhost:8080/api/products/{id} |
| DELETE | http://localhost:8080/api/products/{id} |

### Category Management APIs

| Method | URL                                       |
| ------ | ----------------------------------------- |
| GET    | http://localhost:8080/api/categories      |
| GET    | http://localhost:8080/api/categories/{id} |
| POST   | http://localhost:8080/api/categories      |
| PUT    | http://localhost:8080/api/categories/{id} |
| DELETE | http://localhost:8080/api/categories/{id} |

### Supplier Management APIs

| Method | URL                                      |
| ------ | ---------------------------------------- |
| GET    | http://localhost:8080/api/suppliers      |
| GET    | http://localhost:8080/api/suppliers/{id} |
| POST   | http://localhost:8080/api/suppliers      |
| PUT    | http://localhost:8080/api/suppliers/{id} |
| DELETE | http://localhost:8080/api/suppliers/{id} |

### Product-Supplier Mapping APIs

| Method | URL                                              |
| ------ | ------------------------------------------------ |
| GET    | http://localhost:8080/api/product-suppliers      |
| POST   | http://localhost:8080/api/product-suppliers      |
| DELETE | http://localhost:8080/api/product-suppliers/{id} |

### Report APIs

| Method | URL                                                                 |
| ------ | ------------------------------------------------------------------- |
| GET    | http://localhost:8080/api/reports/products-by-category/{categoryId} |
| GET    | http://localhost:8080/api/reports/low-stock-products                |

